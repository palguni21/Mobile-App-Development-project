## Save-App-with-SQLite

This repository contains the implementation of note and photo saving and sharing android app.

 See the video demonstration: https://bit.ly/2AKxtHa
